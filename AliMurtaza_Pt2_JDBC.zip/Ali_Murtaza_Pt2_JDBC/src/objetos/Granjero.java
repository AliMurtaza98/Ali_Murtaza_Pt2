package objetos;

public class Granjero {
	private int id, puntos, nivel;
	private float dinero;
	private String nombre, descripcion;
	
	public Granjero(int id, String nombre, String descripcion, float dinero, int puntos, int nivel) {
		this.id = id;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.dinero = dinero;
		this.puntos = puntos;
		this.nivel = nivel;
	}

	public Granjero(String nombre) {
		this.id=id;
		this.nombre = nombre;
		this.descripcion = "agresivo";
		this.dinero = 2000;
		this.puntos = 5000;
		this.nivel = 10;
	}

	// Getters
	public int getId() {
		return id;
	}

	public int getPuntos() {
		return puntos;
	}

	public int getNivel() {
		return nivel;
	}

	public float getDinero() {
		return dinero;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	// Setters
	public void setId(int id) {
		this.id = id;
	}

	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public void setDinero(float dinero) {
		this.dinero = dinero;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Granjeros [id=" + id + ", puntos=" + puntos + ", nivel=" + nivel + ", dinero=" + dinero + ", nombre="
				+ nombre + ", descripcion=" + descripcion + "]";
	}

}
