package main;

import java.util.Scanner;

import objetos.Granjero;
import pt.Metodos;

public class Main {

	public static void main(String[] args) {
		Metodos m = new Metodos();
		int opc = 0;
		int o = 0;
		Scanner lector = new Scanner(System.in);

		do {
			System.out.println("----------------------------------------------");
			System.out.println("                    Menu");
			System.out.println("----------------------------------------------");
			System.out.println("1 - Mostrar bases de datos.");
			System.out.println("2 - Mostrar tablas.");
			System.out.println("3 - Insertar granjeros en ArrayList ordenados por el dinero.");
			System.out.println("4 - Ordenar ArrayList.");
			System.out.println("5 - Registrar Granjero por Nombre.");
			System.out.println("6 - Buscar Granjero por Nombre o Descripcion.");
			System.out.println("7 - Subir nivel granjero.");
			System.out.println("8 - Eliminar granjero.");
			System.out.println("9 - Salir.");
			System.out.print("Opcion: ");
			opc = lector.nextInt();

			if (opc == 1) {
				m.showDatabases();

			} else if (opc == 2) {
				m.showColumnsDatabase();

			} else if (opc == 3) {
				m.insertArrayList();
				System.out.println();

			} else if (opc == 4) {
				do {
					System.out.println("1 - Ordenar por nombre.");
					System.out.println("2 - Ordenar por dinero.");
					System.out.println("3 - Ordenar por puntos.");
					System.out.println("4 - Salir.");
					System.out.print("Opcion: ");
					o = lector.nextInt();
					if (o == 1) {
						System.out.println(" --------------------------- ");
						System.out.println("|   ArrayList sin ordenar   |");
						System.out.println(" --------------------------- ");
						for (Granjero objeto : m.arraylist_granjeros) {
							System.out.println(objeto);
						}
						/* Se ordena el ArrayList por nombre */
						m.ordenar_al_nombre(m.arraylist_granjeros);
						System.out.println(" --------------------------- ");
						System.out.println("|   ArrayList con ordenar   |");
						System.out.println(" --------------------------- ");
						for (Granjero objeto : m.arraylist_granjeros) {
							System.out.println(objeto);
						}
						System.out.println("");
					} else if (o == 2) {
						System.out.println(" --------------------------- ");
						System.out.println("|   ArrayList sin ordenar   |");
						System.out.println(" --------------------------- ");
						for (Granjero objeto : m.arraylist_granjeros) {
							System.out.println(objeto);
						}
						/*
						 * Como anteriormente se anaden los granjeros ordenamos, en este caso ordenamos
						 * de mayor cantidad de dinero a menor
						 */
						m.ordenar_al_dinero(m.arraylist_granjeros);
						System.out.println(" --------------------------- ");
						System.out.println("|   ArrayList con ordenar   |");
						System.out.println(" --------------------------- ");
						for (Granjero objeto : m.arraylist_granjeros) {
							System.out.println(objeto);
						}
						System.out.println("");
					} else if (o == 3) {
						System.out.println(" --------------------------- ");
						System.out.println("|   ArrayList sin ordenar   |");
						System.out.println(" --------------------------- ");
						for (Granjero objeto : m.arraylist_granjeros) {
							System.out.println(objeto);
						}
						/* Se ordena el ArrayList por puntos */
						m.ordenar_al_puntos(m.arraylist_granjeros);
						System.out.println(" --------------------------- ");
						System.out.println("|   ArrayList con ordenar   |");
						System.out.println(" --------------------------- ");
						for (Granjero objeto : m.arraylist_granjeros) {
							System.out.println(objeto);
						}
						System.out.println("");
					}
				} while (o != 4);

			} else if (opc == 5) {
				System.out.println("Introduce el nombre: ");
				String nombre = lector.next();
				m.insertarGranjeroPorNombre(nombre);
			} else if (opc == 7) {
				System.out.println("Introduce el nombre del granjero a modificar: ");
				String nombre = lector.next();
				m.modificarGranjero(nombre);
			} else if (opc == 8) {
				System.out.println("Introduce la id del granjero a eliminar: ");
				int id= lector.nextInt();
				m.eliminarGranjero(id);
			} else if (opc == 9) {
				System.out.println("Bye Bye.");
			}
		} while (opc != 9);

	}
}
