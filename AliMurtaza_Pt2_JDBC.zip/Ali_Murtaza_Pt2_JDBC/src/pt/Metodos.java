package pt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;

import comparators.*;
import objetos.Granjero;

public class Metodos {
	public static ArrayList<Granjero> arraylist_granjeros = new ArrayList<Granjero>();

	private Connection conn = null;
	private PreparedStatement preparedStmt = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private String url = "jdbc:mysql://localhost/farmville";
	private String usuario = "root";
	private String psw = "";

	/* Metodo para conectar a la base de datos */
	public Connection getConnection() {
		try {
			if (conn != null & rs != null & preparedStmt != null & stmt != null) {
				conn.close();
				rs.close();
				preparedStmt.close();
				stmt.close();
			}
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, usuario, psw);
		} catch (Exception e) {
			System.out.print("Couldn't connect to database: " + e);
		}
		return conn;
	}

	/* Metodo para mostrar todas las base de datos */
	public void showDatabases() {
		getConnection();
		String query = "show databases;";
		try {
			preparedStmt = conn.prepareStatement(query);
			ResultSet rs = preparedStmt.executeQuery();
			System.out.println(" ---------------------- ");
			System.out.println("|      DATABASES       |");
			System.out.println(" ---------------------- ");
			while (rs.next()) {
				System.out.println("- " + rs.getString("database"));
			}
			System.out.println("");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/* Metodo para mostrar las columnas de la base de datos */
	public void showColumnsDatabase() {
		ArrayList<Granjero> arraylist_granjeros = new ArrayList<Granjero>();
		getConnection();
		String query = "show tables;";
		try {
			preparedStmt = conn.prepareStatement(query);
			ResultSet rs = preparedStmt.executeQuery();
			System.out.println(" ---------------------- ");
			System.out.println("|       TABLES         |");
			System.out.println(" ---------------------- ");
			while (rs.next()) {
				System.out.println("- " + rs.getString("tables_in_farmville"));
			}
			System.out.println(arraylist_granjeros.size());
			System.out.println("");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/* Metodo para insertar todos los objetos de la base de datos en un arraylist */
	public void insertArrayList() {
		getConnection();
		String query = "SELECT * FROM granjeros ORDER BY dinero;";
		try {
			preparedStmt = conn.prepareStatement(query);
			ResultSet rs = preparedStmt.executeQuery();
			System.out.println(" --------------------- ");
			System.out.println("|     ArrayList       |");
			System.out.println(" --------------------- ");
			while (rs.next()) {
				Granjero g = new Granjero(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getInt(5),
						rs.getInt(6));
				arraylist_granjeros.add(g);
			}
			System.out.println("Cantidad granjeros: " + arraylist_granjeros.size());
			System.out.println("");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/* Ordenacion por nombre del arraylist */
	public void ordenar_al_nombre(ArrayList<Granjero> arraylist_granjeros) {
		Collections.sort(arraylist_granjeros, new CompararPorNombre());
	}

	/* Ordenacion por dinero del arraylist */
	public void ordenar_al_dinero(ArrayList<Granjero> arraylist_granjeros) {
		Collections.sort(arraylist_granjeros, new CompararPorDinero());
	}

	/* Ordenacion por puntos del arraylist */
	public void ordenar_al_puntos(ArrayList<Granjero> arraylist_granjeros) {
		Collections.sort(arraylist_granjeros, new CompararPorPuntos());

	}

	/* Metodo para insertar un granjero indicando el nombre */
	public void insertarGranjeroPorNombre(String nombre) {
		getConnection();
		Granjero g = new Granjero(nombre);
		String query = "INSERT INTO granjeros VALUES(?,?,?,?,?,?)";
		try {
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setInt(1, g.getId());
			preparedStmt.setString(2, g.getNombre());
			preparedStmt.setString(3, g.getDescripcion());
			preparedStmt.setFloat(4, g.getDinero());
			preparedStmt.setInt(5, g.getPuntos());
			preparedStmt.setInt(6, g.getNivel());
			preparedStmt.executeUpdate(); 
			System.out.println("Nuevo Granjero:  " + g.getNombre());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void modificarGranjero(String nombre) {
		getConnection();
		String query = "UPDATE granjeros SET nivel = nivel + 1 WHERE nombre = ?";
		try {
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setString(1, nombre);
			preparedStmt.executeUpdate();
			System.out.println("Nivel del Granjero: "+ nombre +" Actualizado +1.");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void eliminarGranjero(int id) {
		getConnection();
		String query = "DELETE FROM granjeros WHERE id = ? ";
		try {
			PreparedStatement st = conn.prepareStatement(query);
			st.setInt(1, id);
			st.executeUpdate();
			System.out.println("Granjero: "+id+" Eliminado.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}