package comparators;

import java.util.Comparator;
import objetos.Granjero;

public class CompararPorNombre implements Comparator<Granjero> {
	@Override
	public int compare(Granjero g1, Granjero g2) {
		return g1.getNombre().compareTo(g2.getNombre());
	}

}
