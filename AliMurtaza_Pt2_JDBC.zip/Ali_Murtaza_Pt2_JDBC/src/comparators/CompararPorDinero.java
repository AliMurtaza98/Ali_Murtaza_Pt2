package comparators;

import java.util.Comparator;

import objetos.Granjero;

public class CompararPorDinero implements Comparator<Granjero>{
	@Override
	public int compare(Granjero g1, Granjero g2) {
		return (int) (g2.getDinero() - g1.getDinero());
	}
 
}
